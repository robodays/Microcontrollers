/*
 * File:        common.h
 * Purpose:     File included by non-standard NXP drivers.
 *              Do not use in your projects, use CMSIS files!
 *
 * Notes:
 */

#ifndef _COMMON_H_
#define _COMMON_H_

//#define DATA_BUF_SIZE   2048
#define DATA_BUF_SIZE   1024

#endif /* _COMMON_H_ */
